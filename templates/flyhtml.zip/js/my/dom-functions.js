// queryselector
const getEle = (ele) => document.querySelector(ele);
const getAllEle = (ele) => document.querySelectorAll(ele);

// get element if want live element then
const getEleById = (id) => document.getElementById(id);
const getEleByCN = (className) => document.getElementsByClassName(className);
